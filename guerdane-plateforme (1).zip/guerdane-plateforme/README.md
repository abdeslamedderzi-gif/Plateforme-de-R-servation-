# Plateforme de Réservation des Terrains de Sport – Commune El Guerdane
# منصة حجز الملاعب الرياضية – جماعة الگيردان

Une plateforme web pour réserver les terrains de sport communaux, **sans compte, sans SMS et sans frais de messagerie**. L'administration de la commune garde le droit exclusif d'accepter ou de refuser chaque demande.

## Contenu du dossier

```
public/                     ← le site à publier (Netlify, Vercel…)
  index.html                  espace citoyens (lien public)
  admin/index.html            espace administration (lien privé)
  confidentialite.html        politique de confidentialité et conditions d'utilisation (FR / AR)
  css/style.css               design (thème « terrain de nuit »)
  js/config.js                ← À REMPLIR : adresse et clé publique Supabase
  js/i18n.js                  traductions français / arabe
  js/common.js, citizen.js, admin.js
  assets/img/                 logo de la commune, photos des terrains
  assets/vendor/              bibliothèque Supabase (v2.119.2)
  _headers, robots.txt        sécurité (HTTPS strict, CSP…) et non-indexation de /admin/
supabase/
  schema.sql                  ← tables, règles de sécurité, fonctions (à exécuter en premier)
  storage.sql                 stockage des photos de terrains
  create-admin.sql            donner l'accès administration à un employé
  donnees-test.sql            données fictives pour la phase d'essai (+ nettoyage)
docs/
  GUIDE-DEPLOIEMENT.md        ← mise en ligne pas à pas
  GUIDE-ADMINISTRATION.md     utilisation quotidienne (FR + résumé AR)
  TESTS.md                    rapport de tests
  captures/                   aperçus téléphone / ordinateur
tests/                        tests automatiques (npm test)
netlify.toml, vercel.json     configuration d'hébergement
```

## Architecture

```
Citoyen (navigateur) ──HTTPS──►  6 fonctions publiques contrôlées  ─┐
                                  (pas d'accès direct aux tables)    │
                                                                     ▼
                                                    Supabase (PostgreSQL)
                                                    • Row Level Security
                                                    • contrainte anti double-réservation
                                                    • journal automatique
                                                                     ▲
Employé (navigateur) ──HTTPS──►  Connexion Supabase Auth ───────────┘
                                  + temps réel (nouvelles demandes)
```

- **Aucun secret dans le navigateur.** La clé de `config.js` est la clé publique, prévue pour être visible. Les mots de passe des employés sont gérés par Supabase Auth.
- **Validation côté serveur.** Téléphone marocain, nom, créneau, délais, fermetures et limite par téléphone sont vérifiés par la base, pas seulement par le formulaire.
- **Double réservation impossible**, même pour deux demandes envoyées à la même seconde : contrainte `EXCLUDE` de PostgreSQL.
- **Anti-abus.** Limite de demandes par adresse IP et par téléphone. Blocage de 5 minutes après 10 recherches incorrectes dans « Ma réservation ».
- **Protection des téléphones.** Ils ne sont jamais renvoyés au public. Ils apparaissent masqués (`06 ** ** 01 01`) dans « Ma réservation ».

## Démarrage

1. Suivre **docs/GUIDE-DEPLOIEMENT.md** (environ 45 minutes).
2. Donner **docs/GUIDE-ADMINISTRATION.md** à l'employé.
3. Faire la déclaration CNDP et compléter `public/confidentialite.html`.

## Tests (pour un informaticien)

```bash
npm install
npm test        # 26 tests base de données + 28 tests de parcours complets
```
