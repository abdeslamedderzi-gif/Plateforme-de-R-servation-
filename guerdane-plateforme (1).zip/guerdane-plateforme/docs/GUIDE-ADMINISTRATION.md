# Guide de l'administration

**Espace administration – Commune El Guerdane**
Adresse : `https://VOTRE-SITE/admin/`. Ne la diffusez pas aux citoyens.

> **Règle d'or :** seule l'administration accepte ou refuse une réservation. Une demande envoyée par un citoyen reste **En attente** tant que vous ne l'avez pas traitée. Il n'y a pas de SMS : prévenez le citoyen par téléphone quand c'est nécessaire.

---

## 1. Se connecter

1. Ouvrez l'adresse de l'administration.
2. Saisissez votre **e-mail** et votre **mot de passe**, puis cliquez sur **Se connecter**.
3. Si vous avez oublié le mot de passe, saisissez votre e-mail, puis cliquez sur **Mot de passe oublié ?**. Un e-mail vous permet d'en choisir un nouveau.
4. Pensez à cliquer sur **Se déconnecter** sur un ordinateur partagé.

Pour changer de langue, utilisez le bouton **العربية / Français** en haut à droite.

## 2. Le tableau de bord

- **Bandeau vert :** les demandes en attente du jour et le taux d'occupation de la semaine.
- **Pastille « En direct » :** quand elle est verte, chaque nouvelle demande s'affiche instantanément, avec une alerte « Nouvelle demande reçue ». Quand elle est grise, la liste se met quand même à jour toutes les 60 secondes, et le bouton **Actualiser** permet de recharger tout de suite.
- **« Aujourd'hui sur les terrains » :** les créneaux de 18h à 23h de chaque terrain. Cliquez sur un créneau réservé pour voir sa fiche.
- **« Demandes à traiter » :** **✓** pour accepter, **✕** pour refuser. Le refus demande une confirmation.

## 3. Traiter les réservations (onglet Réservations)

- **Rechercher** par nom, nom d'association, numéro de réservation ou téléphone.
- **Filtrer** par date, terrain, type (individuelle ou association) et statut.
- Boutons disponibles sur chaque ligne :
  - **Accepter :** la réservation passe à « Acceptée ». Le citoyen le voit dans « Ma réservation ».
  - **Refuser :** le créneau redevient libre pour les autres citoyens.
  - **Annuler :** pour une réservation déjà acceptée qui ne peut plus avoir lieu.
  - **Modifier :** changer le terrain, la date, l'heure, le nom, le téléphone ou ajouter une note interne. Un conflit avec une autre réservation est refusé automatiquement.
  - **Détails :** fiche complète. Le bouton **Historique** montre qui a fait quoi et quand. Le numéro de téléphone est cliquable pour appeler.
  - **Supprimer** (super-administrateur uniquement) : suppression définitive, réservée aux erreurs ou aux données de test.

Statuts :
- **En attente :** demande reçue, pas encore décidée.
- **Acceptée :** le citoyen peut venir.
- **Refusée :** le créneau n'est pas accordé.
- **Annulée :** annulée par le citoyen ou par la commune.
- **Terminée :** le créneau accepté est passé. Ce statut est mis automatiquement.

## 4. Planning

Vues **Jour**, **Semaine** et **Mois**, avec des filtres par terrain et par statut. Les couleurs :
- orange = en attente ;
- vert = acceptée ;
- gris rayé = créneau bloqué ;
- barré = annulée ou refusée.

Cliquez sur une réservation pour l'ouvrir. En vue Mois, cliquez sur un jour pour l'ouvrir en vue Jour.

## 5. Terrains (super-administrateur)

- Modifier le nom et la description, en français et en arabe.
- Modifier les heures d'ouverture et les jours d'ouverture.
- **Changer la photo** : JPG, PNG ou WebP, 3 Mo maximum.
- **Fermer temporairement un terrain** (entretien, travaux) : décochez « Terrain ouvert aux réservations » et indiquez un motif. Les citoyens voient « Fermé temporairement » avec ce motif.
- **Bloquer un créneau précis** (événement, match officiel) : tout administrateur peut le faire, en bas de la page. Le créneau devient indisponible pour les citoyens.

Les réservations déjà acceptées sur une période fermée ne sont pas annulées automatiquement. Vérifiez le planning et prévenez les personnes concernées.

## 6. Horaires et règles (super-administrateur)

- **Durée d'un créneau :** 60 minutes par défaut.
- **Délai minimum avant réservation :** 2 heures par défaut.
- **Réservation au maximum à l'avance :** 30 jours par défaut.
- **Délai d'annulation par le citoyen :** 24 heures par défaut.
- **Demandes actives maximum par téléphone :** 3 par défaut, pour limiter les abus.
- **Téléphone et adresse de la commune**, affichés en bas des pages.
- **Jours de fermeture et périodes exceptionnelles :** pour tous les terrains ou un seul.

Tous ces réglages s'appliquent immédiatement, sans intervention d'un développeur.

## 7. Rapports

Choisissez une période (journalier, hebdomadaire, mensuel ou annuel) et une date de référence. Deux boutons sont disponibles :
- **Exporter Excel (CSV)**, qui s'ouvre dans Excel ;
- **Exporter PDF / Imprimer**, puis choisissez « Enregistrer en PDF » dans la fenêtre d'impression.

## 8. Journal

Il contient l'historique de toutes les opérations : créations, décisions, modifications, blocages et changements de règles. Pour chaque opération, on y voit la date et l'auteur (citoyen ou administration).

## 9. Mon compte

Pour changer votre mot de passe, saisissez le mot de passe actuel, puis le nouveau deux fois. Il faut au moins 10 caractères, avec des lettres et des chiffres.

## 10. Ajouter ou retirer un employé

Cela se fait dans Supabase, par la personne responsable du projet :
- **Ajouter :** voir l'étape 4 du guide de déploiement.
- **Retirer :** exécutez dans SQL Editor
  `delete from public.admin_users where user_id = (select id from auth.users where email = 'ancien@exemple.ma');`
  puis supprimez l'utilisateur dans Authentication → Users.

## Bonnes pratiques de protection des données

- Ne communiquez jamais un numéro de citoyen à un tiers.
- N'exportez les rapports que pour un usage interne. Supprimez les fichiers Excel devenus inutiles.
- Ne partagez pas votre mot de passe. Chaque employé doit avoir son propre compte.
- N'utilisez jamais les données de vrais citoyens pour des tests.

---

## ملخص بالعربية

- **الدخول:** افتح رابط الإدارة، ثم أدخل البريد الإلكتروني وكلمة المرور.
- **معالجة الطلبات:** في «لوحة القيادة» أو «الحجوزات»، اضغط **قبول** أو **رفض**. الإدارة وحدها تقبل أو ترفض الطلبات.
- **الطلبات الجديدة** تظهر مباشرة مع تنبيه («مباشر» باللون الأخضر).
- **لا توجد رسائل نصية:** اتصل بالمواطن هاتفيا عند الحاجة، فالرقم قابل للضغط.
- **الملاعب:** الإغلاق المؤقت، وحجب توقيت، وتغيير الصورة والمواعيد.
- **المواعيد والقواعد:** مدة التوقيت، والمهل، وأيام الإغلاق.
- **التقارير:** تصدير Excel أو PDF.
- **السجل:** كل العمليات مسجلة.
- **حسابي:** لتغيير كلمة المرور.
