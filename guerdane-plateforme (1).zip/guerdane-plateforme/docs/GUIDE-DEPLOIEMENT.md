# Guide de déploiement — pas à pas

**Plateforme de Réservation des Terrains de Sport – Commune El Guerdane**
**منصة حجز الملاعب الرياضية – جماعة الگيردان**

Durée : environ 45 minutes la première fois. Aucune compétence en programmation n'est nécessaire : il suffit de copier-coller et de cliquer.

Vous aurez besoin de :
- une adresse e-mail de la commune (pour créer les comptes) ;
- le dossier du projet décompressé sur votre ordinateur.

À la fin, vous aurez :
- **le lien public pour les citoyens**, par exemple `https://terrains-guerdane.netlify.app/` ;
- **le lien privé de l'administration**, par exemple `https://terrains-guerdane.netlify.app/admin/`.

---

## Étape 1 — Créer la base de données (Supabase)

1. Allez sur **https://supabase.com** et cliquez sur **Start your project**. Créez un compte avec l'e-mail de la commune.
2. Cliquez sur **New project** et remplissez :
   - **Name :** `guerdane-terrains`
   - **Database Password :** cliquez sur *Generate a password*, puis **notez-le en lieu sûr**. Vous n'en aurez pas besoin au quotidien.
   - **Region :** choisissez la plus proche du Maroc, par exemple *West EU (Paris)* ou *Central EU (Frankfurt)*.
3. Cliquez sur **Create new project** et attendez environ 2 minutes.

## Étape 2 — Installer les tables et les règles de sécurité

1. Dans le menu de gauche, ouvrez **SQL Editor**, puis cliquez sur **New query**.
2. Ouvrez le fichier `supabase/schema.sql` avec le Bloc-notes, sélectionnez tout (**Ctrl + A**), copiez, puis collez dans Supabase.
3. Cliquez sur **Run**. Le message **Success. No rows returned** doit apparaître.
4. Faites de même avec `supabase/storage.sql` : nouvelle requête, coller, **Run**. Ce fichier active l'envoi des photos de terrains.

> Si vous voyez une erreur, ne relancez pas les fichiers au hasard. Notez le message exact et envoyez-le à la personne qui vous accompagne.

## Étape 3 — Sécuriser la connexion de l'administration

1. Menu **Authentication** → **Sign In / Providers** (ou **Providers**) → **Email** :
   - laissez **Enable Email provider** activé ;
   - **désactivez** **Allow new users to sign up**. Ainsi, personne ne peut se créer un compte tout seul.
2. Menu **Authentication** → **URL Configuration** :
   - **Site URL :** l'adresse de l'administration, à remplir après l'étape 6, par exemple `https://terrains-guerdane.netlify.app/admin/` ;
   - **Redirect URLs :** ajoutez la même adresse. Elle sert au lien « Mot de passe oublié ».

## Étape 4 — Créer le compte de l'employé

1. Menu **Authentication** → **Users** → **Add user** → **Create new user**.
2. Saisissez l'e-mail de l'employé et un mot de passe solide : au moins 10 caractères, avec des lettres et des chiffres.
3. Cochez **Auto Confirm User**, puis cliquez sur **Create user**.
4. Ouvrez **SQL Editor** → **New query** et collez le contenu de `supabase/create-admin.sql`.
5. Remplacez `REMPLACER@exemple.ma` par l'e-mail de l'employé, puis cliquez sur **Run**.

Le rôle `superadmin` donne tous les droits. Le rôle `admin` permet de traiter les demandes, mais pas de supprimer des réservations ni de changer les paramètres.

## Étape 5 — Relier le site à la base

1. Menu **Project Settings** (roue dentée) → **API Keys** (ou **API**).
2. Copiez :
   - le **Project URL**, de la forme `https://abcdefgh.supabase.co` ;
   - la clé **publishable** (elle commence par `sb_publishable_`) ou, à défaut, la clé **anon public**.
3. Ouvrez `public/js/config.js` avec le Bloc-notes et remplacez les deux valeurs :

```js
window.APP_CONFIG = {
  SUPABASE_URL: 'https://abcdefgh.supabase.co',
  SUPABASE_ANON_KEY: 'sb_publishable_xxxxxxxxxxxxxxxx'
};
```

> **Ne mettez JAMAIS la clé `service_role` ou `secret`.**
> La clé publique, elle, peut être vue par tout le monde sans danger : elle ne permet que les 6 opérations citoyennes prévues dans la base. Toutes les autres données sont protégées par la base de données elle-même.

## Étape 6 — Mettre le site en ligne (Netlify, gratuit, HTTPS automatique)

**Méthode la plus simple (glisser-déposer) :**

1. Allez sur **https://app.netlify.com** et créez un compte.
2. Ouvrez **Add new site** → **Deploy manually**.
3. Faites glisser le dossier **`public`** (pas le dossier du projet entier) dans la zone prévue.
4. Après quelques secondes, Netlify donne une adresse du type `https://nom-aleatoire.netlify.app`.
5. Dans **Site configuration** → **Change site name**, choisissez par exemple `terrains-guerdane`.

Le HTTPS est activé automatiquement. Les en-têtes de sécurité (fichier `public/_headers`) sont appliqués automatiquement.

*Autre option : Vercel. Importez le dossier du projet sur https://vercel.com. Le fichier `vercel.json` est déjà prêt.*

Retournez ensuite à l'**étape 3** pour remplir le Site URL et les Redirect URLs avec l'adresse définitive.

## Étape 7 — Nom de domaine (facultatif)

Si la commune possède un domaine, par exemple `guerdane.ma` :

1. Netlify → **Domain management** → **Add a domain** → `reservation.guerdane.ma`.
2. Chez le gestionnaire du domaine, ajoutez l'enregistrement DNS indiqué par Netlify (un `CNAME` vers `terrains-guerdane.netlify.app`).
3. Netlify crée le certificat HTTPS automatiquement.
4. Mettez à jour le Site URL et les Redirect URLs dans Supabase (étape 3).

## Étape 8 — Vérifier avant d'annoncer le service

Le projet n'est considéré comme **réellement en ligne** que lorsque tous ces points sont validés :

- [ ] Le lien public s'ouvre sur téléphone et sur ordinateur, en arabe et en français.
- [ ] Une réservation de test, avec le nom `TEST Essai` et le numéro `0600000000`, affiche un ticket avec un numéro `GRD-...`.
- [ ] Ce créneau apparaît ensuite comme indisponible.
- [ ] La demande apparaît dans `/admin/` sans recharger la page (pastille « En direct » verte).
- [ ] « Accepter » fonctionne, et « Ma réservation » affiche alors **Acceptée**.
- [ ] Une deuxième réservation sur le même créneau est refusée.
- [ ] Un mauvais mot de passe sur `/admin/` est refusé.
- [ ] Supprimez les données de test : `SQL Editor` → `delete from public.reservations where full_name like 'TEST%';`

Les données de test fictives de `supabase/donnees-test.sql` peuvent servir pendant la phase d'essai. **N'utilisez jamais les noms ou numéros de vrais citoyens pour les tests.**

## Étape 9 — Avant l'ouverture au public

- Complétez les mentions entre crochets dans `public/confidentialite.html` : coordonnées, durée de conservation, n° CNDP.
- Faites la **déclaration à la CNDP** (loi 09-08). Si l'hébergement est hors du Maroc, demandez-lui si un transfert de données nécessite une autorisation.
- Indiquez le téléphone de la commune dans **Administration → Horaires et règles**. Il s'affichera en bas de page.

---

## Mettre à jour le site

- **Modifier un texte ou une image :** modifiez le fichier dans `public/`, puis refaites le glisser-déposer du dossier `public` dans Netlify, onglet **Deploys**. L'ancienne version est remplacée en quelques secondes. On peut revenir en arrière depuis l'historique des déploiements.
- **Modifier la base de données :** n'exécutez **jamais** à nouveau `schema.sql` sur une base qui contient des données sans l'avoir vérifié avec votre prestataire. Les évolutions se font par de petits scripts SQL dédiés.
- **Lancer les tests automatiques** (pour un informaticien) : dans le dossier du projet, `npm install` puis `npm test`.

## Sauvegardes et continuité

- **Plan gratuit de Supabase :** il ne fait pas de sauvegarde automatique. De plus, Supabase met en pause les projets du plan gratuit qui ont peu d'activité sur une période de 7 jours (source : https://supabase.com/docs/guides/platform/project-pausing). Une plateforme utilisée chaque jour par les citoyens ne devrait pas être concernée. Si cela arrive, il suffit d'ouvrir le tableau de bord Supabase et de cliquer sur *Resume project*.
- **Recommandé pour un service public :** le plan **Pro** de Supabase, avec des sauvegardes quotidiennes et sans mise en pause.
- **Dans tous les cas :** exportez chaque mois le rapport Excel (Administration → Rapports → période « Annuel »).
- **Conservation des données** (exemple sur 12 mois, à exécuter une fois par mois dans SQL Editor) :
  ```sql
  delete from public.reservations where date < current_date - interval '12 months';
  delete from public.audit_log    where at   < now()        - interval '12 months';
  ```

## En cas de problème

| Ce que vous voyez | Cause probable | Solution |
|---|---|---|
| Page « Configuration requise » | `config.js` n'est pas rempli | Étape 5 |
| « Service momentanément indisponible » | Projet Supabase en pause ou mauvaise clé | Supabase → Resume project, vérifier la clé |
| « Ce compte n'a pas accès à l'administration » | Compte créé mais pas inscrit comme administrateur | Étape 4, points 4 et 5 |
| La pastille « En direct » reste grise | Temps réel indisponible | La liste se met quand même à jour toutes les 60 secondes, ou cliquez sur *Actualiser* |
| Le lien « Mot de passe oublié » n'arrive pas | URL de redirection absente, ou limite d'envoi d'e-mails du plan gratuit | Étape 3, ou réinitialiser le mot de passe depuis Supabase → Users |
