# Rapport de tests — 24 novembre 2026

Tests exécutés sur le **vrai schéma PostgreSQL** (`supabase/schema.sql`) et sur les **vraies pages** du dossier `public/`.
Les rôles de Supabase sont simulés : `anon` pour les citoyens, `authenticated` pour les agents, et `auth.uid()`.
Toutes les données de test sont fictives (noms « TEST… », numéros `0600000xxx`).

Pour relancer les tests : `npm install` puis `npm test`.

## Base de données et sécurité — 26/26 tests réussis
- ✔ 1. Un citoyen crée une demande (statut En attente, numéro unique)
- ✔ 6a. Le même créneau ne peut pas être réservé deux fois
- ✔ 6b. Deux demandes simultanées : la contrainte de la base en refuse une
- ✔ 7. Terrain 1 et Terrain 2 sont indépendants (même heure possible)
- ✔ Créneau réservé affiché comme indisponible
- ✔ Téléphone obligatoire et au format marocain
- ✔ Nom complet, consentement et association validés côté serveur
- ✔ Créneau hors horaires ou mal aligné refusé
- ✔ Date passée ou trop lointaine refusée
- ✔ Limite de 3 demandes actives par téléphone
- ✔ 10. Le citoyen n’a aucun accès direct aux tables
- ✔ 10b. Un compte connecté mais non autorisé ne voit rien
- ✔ 2. La demande apparaît dans la liste de l’administration
- ✔ 3. L’administration accepte une demande
- ✔ 4. L’administration refuse une demande (le créneau redevient libre)
- ✔ 5. Le citoyen voit le nouveau statut (Acceptée / Refusée)
- ✔ Suivi refusé si le numéro et le téléphone ne correspondent pas
- ✔ Blocage après 10 essais incorrects (anti-devinette)
- ✔ Annulation par le citoyen avant le délai
- ✔ Créneau bloqué et fermeture temporaire d’un terrain
- ✔ Jours de fermeture exceptionnels
- ✔ Suppression réservée au super-administrateur
- ✔ Modification d’horaire par l’administration contrôlée (conflits refusés)
- ✔ Journal des opérations alimenté automatiquement
- ✔ Anti-abus : 30 demandes par heure et par adresse IP
- ✔ Passage automatique en "Terminée" (admin)

## Parcours complets citoyen et administration (navigateur simulé) — 28/28 tests réussis
- ✔ Accueil : chargement, tableau "Ce soir" et aucun lien vers l’administration
- ✔ 1 + 7. Réservation complète sur le Terrain 1 puis sur le Terrain 2
- ✔ Validation du formulaire (téléphone obligatoire et format)
- ✔ 6. Le créneau réservé disparaît des horaires libres
- ✔ 6b. Double réservation : si un autre citoyen prend le créneau entre-temps, la demande est refusée
- ✔ 5. Suivi : numéro + téléphone → statut En attente
- ✔ Suivi avec un mauvais téléphone → introuvable
- ✔ 8. Arabe (RTL) et français (LTR)
- ✔ 10. Protection : mauvais mot de passe refusé
- ✔ 10b. Protection : compte connecté mais non inscrit comme administrateur → refusé
- ✔ 10c. Aucun mot de passe ni clé secrète dans les fichiers du navigateur
- ✔ 2. La demande du citoyen apparaît dans le tableau de bord
- ✔ Temps réel : une nouvelle demande s’affiche sans recharger
- ✔ 3. Accepter une demande (statut mis à jour dans la base)
- ✔ 4. Refuser une demande (avec confirmation)
- ✔ 5. Le citoyen voit "Acceptée" et "Refusée"
- ✔ Recherche par nom / téléphone et filtres
- ✔ Détails et historique d’une réservation
- ✔ Administrateur simple : pas de suppression ni de paramètres
- ✔ Planning jour / semaine / mois
- ✔ Rapports et journal
- ✔ Super-administrateur : fermer temporairement le Terrain 2 (visible côté citoyen)
- ✔ Contrôle des horaires : bloquer un créneau
- ✔ Règles modifiables sans développeur (délai d’annulation)
- ✔ Suppression d’une réservation par le super-administrateur
- ✔ Changement du mot de passe administrateur
- ✔ 8b. Administration en arabe (RTL)
- ✔ 11. Aucun SMS ni OTP dans le code livré

## Correspondance avec les 11 tests demandés

| # | Test demandé | Résultat |
|---|---|---|
| 1 | Créer une nouvelle demande | ✔ base de données et navigateur |
| 2 | La demande apparaît dans l'administration | ✔ y compris en temps réel |
| 3 | Accepter une demande | ✔ |
| 4 | Refuser une demande | ✔ le créneau redevient libre |
| 5 | Mise à jour du statut chez le citoyen | ✔ « Acceptée » / « Refusée » |
| 6 | Pas deux réservations sur le même créneau | ✔ y compris deux demandes simultanées (contrainte d'exclusion PostgreSQL) |
| 7 | Terrain 1 et Terrain 2 | ✔ |
| 8 | Arabe et français | ✔ RTL / LTR, citoyen et administration |
| 9 | Téléphone et ordinateur | ✔ vérification visuelle à 390 px et 1300 px (voir `docs/captures/`) |
| 10 | Protection de l'administration | ✔ mauvais mot de passe, compte non autorisé, aucun accès direct aux tables, aucun secret dans le navigateur |
| 11 | Aucun SMS ni OTP | ✔ vérifié dans tout le code livré |

## Ce qui n'a pas pu être testé ici

- **Le déploiement réel** (Supabase en ligne et Netlify) : il nécessite les comptes de la commune. Suivez l'étape 8 du guide de déploiement pour valider en ligne.
- **L'envoi de l'e-mail « mot de passe oublié »** : il est géré par Supabase.
- **L'envoi des photos** vers Supabase Storage : simulé dans les tests.
