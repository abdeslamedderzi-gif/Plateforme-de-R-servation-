-- =====================================================================
--  Donner l'accès administration à un compte.
--  1) Créez d'abord l'utilisateur dans Supabase > Authentication > Users >
--     "Add user" > "Create new user" (e-mail + mot de passe, cochez
--     "Auto Confirm User").
--  2) Remplacez l'e-mail ci-dessous puis exécutez ce script.
--  Rôles : 'superadmin' = tous les droits ; 'admin' = traitement des
--  demandes et blocage de créneaux (sans suppression ni paramètres).
-- =====================================================================
insert into public.admin_users (user_id, display_name, role)
select id, 'Responsable des terrains', 'superadmin'
from auth.users where email = 'REMPLACER@exemple.ma'
on conflict (user_id) do update set role = excluded.role, display_name = excluded.display_name;

-- Retirer un accès :
-- delete from public.admin_users where user_id = (select id from auth.users where email = 'ancien@exemple.ma');
