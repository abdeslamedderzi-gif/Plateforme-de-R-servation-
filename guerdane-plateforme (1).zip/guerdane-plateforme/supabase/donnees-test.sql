-- =====================================================================
--  Données de TEST fictives (ne jamais utiliser de vraies personnes).
--  Toutes les lignes de test ont un nom qui commence par "TEST".
--  Pour les supprimer avant l'ouverture au public : voir plus bas.
-- =====================================================================
select public.create_reservation(1::smallint, (public.local_now()::date + 1), '19:00', 'indiv', 'TEST Citoyen Un', '0600000001', null, 'fr', true);
select public.create_reservation(2::smallint, (public.local_now()::date + 1), '20:00', 'assoc', 'TEST Responsable', '0600000002', 'TEST Association', 'ar', true);
select public.create_reservation(1::smallint, (public.local_now()::date + 2), '21:00', 'indiv', 'TEST Citoyen Deux', '0600000003', null, 'fr', true);

-- ---------------------------------------------------------------------
--  NETTOYAGE avant la mise en service publique :
-- delete from public.reservations where full_name like 'TEST%';
-- delete from public.audit_log where reservation_id is not null
--   and reservation_id not in (select id from public.reservations);
-- delete from public.rate_events;
-- ---------------------------------------------------------------------
