-- =====================================================================
--  Plateforme de Réservation des Terrains de Sport – Commune El Guerdane
--  منصة حجز الملاعب الرياضية – جماعة الگيردان
--
--  Schéma de base de données Supabase (PostgreSQL).
--  À exécuter UNE SEULE FOIS dans : Supabase > SQL Editor > New query.
--
--  Principes de sécurité :
--   * Les citoyens (rôle "anon") n'ont AUCUN accès direct aux tables.
--     Ils passent uniquement par 6 fonctions contrôlées (RPC) qui
--     valident les données côté serveur et ne renvoient jamais le
--     téléphone d'un autre citoyen.
--   * L'administration se connecte avec Supabase Auth (e-mail + mot de
--     passe). Seuls les comptes inscrits dans "admin_users" ont accès
--     aux données (Row Level Security).
--   * La double réservation est impossible, même pour deux demandes
--     envoyées à la même seconde : contrainte d'exclusion PostgreSQL.
--   * Aucun SMS, aucun OTP, aucun service payant.
-- =====================================================================

create extension if not exists btree_gist;

-- ---------------------------------------------------------------------
-- 1. Tables
-- ---------------------------------------------------------------------

create table if not exists public.terrains (
  id            smallint primary key,
  name_fr       text not null,
  name_ar       text not null,
  desc_fr       text not null default '',
  desc_ar       text not null default '',
  image_url     text,
  open_time     time not null default '18:00',
  close_time    time not null default '23:00',
  open_days     smallint[] not null default '{0,1,2,3,4,5,6}',   -- 0 = dimanche … 6 = samedi
  active        boolean not null default true,                    -- false = fermé temporairement
  closed_reason text,
  sort          smallint not null default 0,
  constraint terrains_hours check (open_time < close_time)
);

create table if not exists public.settings (
  id                   boolean primary key default true check (id),  -- une seule ligne
  slot_minutes         smallint not null default 60 check (slot_minutes between 15 and 240),
  min_delay_hours      smallint not null default 2  check (min_delay_hours between 0 and 168),
  max_days_ahead       smallint not null default 30 check (max_days_ahead between 1 and 365),
  cancel_hours         smallint not null default 24 check (cancel_hours between 0 and 168),
  max_active_per_phone smallint not null default 3  check (max_active_per_phone between 1 and 20),
  contact_phone        text,
  contact_address_fr   text default 'Siège de la Commune El Guerdane, Province de Taroudant',
  contact_address_ar   text default 'مقر جماعة الگيردان، إقليم تارودانت',
  updated_at           timestamptz not null default now()
);

create table if not exists public.closures (          -- jours de fermeture / périodes exceptionnelles
  id         bigserial primary key,
  terrain_id smallint references public.terrains(id) on delete cascade,  -- null = tous les terrains
  date_from  date not null,
  date_to    date not null,
  reason     text,
  created_at timestamptz not null default now(),
  constraint closures_range check (date_from <= date_to)
);

create table if not exists public.blocks (            -- créneaux bloqués (entretien, événement…)
  id         bigserial primary key,
  terrain_id smallint not null references public.terrains(id) on delete cascade,
  date       date not null,
  start_time time not null,
  end_time   time not null,
  reason     text,
  created_at timestamptz not null default now(),
  constraint blocks_range check (start_time < end_time)
);

create table if not exists public.reservations (
  id          bigserial primary key,
  num         text unique,
  terrain_id  smallint not null references public.terrains(id),
  date        date not null,
  start_time  time not null,
  end_time    time not null,
  type        text not null check (type in ('indiv','assoc')),
  full_name   text not null check (char_length(full_name) between 3 and 80),
  phone       text not null check (phone ~ '^0[5-7][0-9]{8}$'),
  assoc_name  text check (assoc_name is null or char_length(assoc_name) between 2 and 120),
  status      text not null default 'pending'
              check (status in ('pending','confirmed','refused','cancelled','done')),
  lang        text not null default 'fr' check (lang in ('fr','ar')),
  admin_note  text,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  decided_by  uuid,
  decided_at  timestamptz,
  constraint reservations_range check (start_time < end_time),
  constraint reservations_assoc check (type = 'indiv' or assoc_name is not null),
  -- ANTI DOUBLE-RÉSERVATION : deux demandes actives ne peuvent jamais se chevaucher
  constraint no_double_booking exclude using gist (
    terrain_id with =,
    tsrange(date + start_time, date + end_time) with &&
  ) where (status in ('pending','confirmed'))
);
create index if not exists reservations_date_idx  on public.reservations (date, terrain_id);
create index if not exists reservations_phone_idx on public.reservations (phone);

create table if not exists public.admin_users (       -- comptes autorisés de la commune
  user_id      uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Administration',
  role         text not null default 'admin' check (role in ('admin','superadmin')),
  created_at   timestamptz not null default now()
);

create table if not exists public.audit_log (         -- historique de toutes les opérations
  id             bigserial primary key,
  at             timestamptz not null default now(),
  actor          uuid,               -- null = citoyen (via la plateforme publique)
  table_name     text not null,
  op             text not null,
  row_id         text,
  reservation_id bigint,
  data           jsonb
);
create index if not exists audit_log_res_idx on public.audit_log (reservation_id);

create table if not exists public.rate_events (       -- limitation anti-abus (interne)
  id   bigserial primary key,
  ip   text not null,
  kind text not null,
  at   timestamptz not null default now()
);
create index if not exists rate_events_idx on public.rate_events (ip, kind, at);

-- ---------------------------------------------------------------------
-- 2. Données initiales
-- ---------------------------------------------------------------------

insert into public.settings default values on conflict do nothing;

insert into public.terrains (id, name_fr, name_ar, desc_fr, desc_ar, sort) values
 (1, 'Terrain 1', 'الملعب 1', 'Terrain de football en gazon synthétique, clôturé et éclairé', 'ملعب كرة القدم بالعشب الاصطناعي، مسيّج ومُنار', 1),
 (2, 'Terrain 2', 'الملعب 2', 'Terrain de proximité en gazon synthétique, éclairé le soir',  'ملعب القرب بالعشب الاصطناعي، مُنار ليلا', 2)
on conflict (id) do nothing;

-- ---------------------------------------------------------------------
-- 3. Fonctions utilitaires
-- ---------------------------------------------------------------------

create or replace function public.local_now() returns timestamp
language sql stable as $$ select (now() at time zone 'Africa/Casablanca') $$;

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.admin_users where user_id = auth.uid())
$$;

create or replace function public.is_superadmin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.admin_users where user_id = auth.uid() and role = 'superadmin')
$$;

create or replace function public.client_ip() returns text
language plpgsql stable as $$
declare h json;
begin
  begin h := current_setting('request.headers', true)::json; exception when others then h := null; end;
  return coalesce(nullif(h->>'cf-connecting-ip', ''), nullif(trim(split_part(h->>'x-forwarded-for', ',', 1)), ''), nullif(h->>'x-real-ip', ''), 'unknown');
end $$;

create or replace function public.norm_phone(p text) returns text
language plpgsql immutable as $$
declare s text := regexp_replace(coalesce(p,''), '[\s\.\-\(\)]', '', 'g');
begin
  if s like '+212%' then s := '0' || substr(s, 5);
  elsif s like '00212%' then s := '0' || substr(s, 6); end if;
  if s ~ '^0[5-7][0-9]{8}$' then return s; end if;
  return null;
end $$;

create or replace function public.mask_phone(p text) returns text
language sql immutable as $$ select substr(p,1,2) || ' ** ** ' || substr(p,7,2) || ' ' || substr(p,9,2) $$;

-- État d'un créneau : free | taken | blocked | past | closed
create or replace function public.slot_state(p_terrain smallint, p_date date, p_start time, p_end time)
returns text language plpgsql stable security definer set search_path = public as $$
declare t public.terrains; s public.settings;
begin
  select * into t from public.terrains where id = p_terrain;
  select * into s from public.settings limit 1;
  if t.id is null or not t.active then return 'closed'; end if;
  if not (extract(dow from p_date)::smallint = any (t.open_days)) then return 'closed'; end if;
  if exists (select 1 from public.closures c where p_date between c.date_from and c.date_to
             and (c.terrain_id is null or c.terrain_id = p_terrain)) then return 'closed'; end if;
  if p_date > (local_now()::date + s.max_days_ahead) then return 'closed'; end if;
  if exists (select 1 from public.reservations r where r.terrain_id = p_terrain and r.date = p_date
             and r.status in ('pending','confirmed') and r.start_time < p_end and p_start < r.end_time) then return 'taken'; end if;
  if exists (select 1 from public.blocks b where b.terrain_id = p_terrain and b.date = p_date
             and b.start_time < p_end and p_start < b.end_time) then return 'blocked'; end if;
  if (p_date + p_start) < local_now() + make_interval(hours => s.min_delay_hours) then return 'past'; end if;
  return 'free';
end $$;

-- ---------------------------------------------------------------------
-- 4. Fonctions publiques (citoyens) – seules portes d'entrée du rôle anon
-- ---------------------------------------------------------------------

-- 4.1 Configuration publique (terrains, règles, date du serveur)
create or replace function public.get_public_config() returns json
language sql stable security definer set search_path = public as $$
  select json_build_object(
    'now', to_char(local_now(), 'YYYY-MM-DD"T"HH24:MI:SS'),
    'settings', (select json_build_object('slot_minutes', slot_minutes, 'min_delay_hours', min_delay_hours,
                  'max_days_ahead', max_days_ahead, 'cancel_hours', cancel_hours,
                  'contact_phone', contact_phone, 'contact_address_fr', contact_address_fr,
                  'contact_address_ar', contact_address_ar) from public.settings limit 1),
    'terrains', coalesce((select json_agg(json_build_object('id', id, 'name_fr', name_fr, 'name_ar', name_ar,
                  'desc_fr', desc_fr, 'desc_ar', desc_ar, 'image_url', image_url,
                  'open_time', to_char(open_time,'HH24:MI'), 'close_time', to_char(close_time,'HH24:MI'),
                  'open_days', open_days, 'active', active, 'closed_reason', closed_reason) order by sort, id)
                  from public.terrains), '[]'::json)
  )
$$;

-- 4.2 Créneaux d'un terrain pour une date (aucune donnée personnelle)
create or replace function public.get_availability(p_terrain smallint, p_date date)
returns table (start_time text, end_time text, state text)
language plpgsql stable security definer set search_path = public as $$
declare t public.terrains; s public.settings; m int;
begin
  select * into t from public.terrains where id = p_terrain;
  select * into s from public.settings limit 1;
  if t.id is null then return; end if;
  m := extract(epoch from t.open_time)::int / 60;
  while m + s.slot_minutes <= extract(epoch from t.close_time)::int / 60 loop
    start_time := to_char(make_time(m/60, m%60, 0), 'HH24:MI');
    end_time   := to_char(make_time((m+s.slot_minutes)/60 % 24, (m+s.slot_minutes)%60, 0), 'HH24:MI');
    state := case when p_date < local_now()::date then 'past'
                  else slot_state(p_terrain, p_date, make_time(m/60, m%60, 0),
                       make_time(m/60, m%60, 0) + make_interval(mins => s.slot_minutes)) end;
    return next;
    m := m + s.slot_minutes;
  end loop;
end $$;

-- 4.3 Calendrier : nombre de créneaux libres par jour (62 jours max)
create or replace function public.get_calendar(p_terrain smallint, p_from date, p_to date)
returns table (day date, free_count int)
language plpgsql stable security definer set search_path = public as $$
declare d date;
begin
  if p_to - p_from > 62 then p_to := p_from + 62; end if;
  d := greatest(p_from, local_now()::date);
  while d <= p_to loop
    day := d;
    select count(*)::int into free_count from public.get_availability(p_terrain, d) a where a.state = 'free';
    return next;
    d := d + 1;
  end loop;
end $$;

-- 4.4 Création d'une demande de réservation (toutes les règles vérifiées ici)
create or replace function public.create_reservation(
  p_terrain smallint, p_date date, p_start text, p_type text, p_full_name text,
  p_phone text, p_assoc_name text default null, p_lang text default 'fr', p_consent boolean default false)
returns json language plpgsql volatile security definer set search_path = public as $$
declare
  s public.settings; t public.terrains; v_phone text; v_name text; v_assoc text;
  v_start time; v_end time; v_state text; v_id bigint; v_num text; v_ip text := client_ip(); off int;
begin
  -- anti-abus : 30 demandes par heure et par adresse IP (les opérateurs mobiles partagent
  -- souvent une même adresse entre plusieurs abonnés : la limite reste donc large ;
  -- la vraie limite est celle par téléphone, plus bas)
  if v_ip <> 'unknown' and (select count(*) from public.rate_events where ip = v_ip and kind = 'create' and at > now() - interval '1 hour') >= 30 then
    raise exception 'RATE_LIMIT';
  end if;

  select * into s from public.settings limit 1;
  select * into t from public.terrains where id = p_terrain;
  if t.id is null then raise exception 'BAD_TERRAIN'; end if;
  if coalesce(p_consent, false) is not true then raise exception 'NO_CONSENT'; end if;
  if p_type not in ('indiv','assoc') then raise exception 'BAD_TYPE'; end if;

  v_name := regexp_replace(trim(coalesce(p_full_name,'')), '\s+', ' ', 'g');
  if char_length(v_name) < 3 or char_length(v_name) > 80 or v_name ~ '[<>{}]' then raise exception 'BAD_NAME'; end if;
  v_phone := norm_phone(p_phone);
  if v_phone is null then raise exception 'BAD_PHONE'; end if;
  if p_type = 'assoc' then
    v_assoc := regexp_replace(trim(coalesce(p_assoc_name,'')), '\s+', ' ', 'g');
    if char_length(v_assoc) < 2 or char_length(v_assoc) > 120 or v_assoc ~ '[<>{}]' then raise exception 'BAD_ASSOC'; end if;
  end if;

  begin v_start := p_start::time; exception when others then raise exception 'BAD_SLOT'; end;
  v_end := v_start + make_interval(mins => s.slot_minutes);
  off := (extract(epoch from v_start)::int - extract(epoch from t.open_time)::int) / 60;
  if v_start < t.open_time or v_end > t.close_time or v_end <= v_start or off % s.slot_minutes <> 0 then
    raise exception 'BAD_SLOT';
  end if;

  if p_date < local_now()::date then raise exception 'SLOT_PAST'; end if;
  v_state := slot_state(p_terrain, p_date, v_start, v_end);
  if v_state = 'taken'   then raise exception 'SLOT_TAKEN'; end if;
  if v_state = 'blocked' then raise exception 'SLOT_BLOCKED'; end if;
  if v_state = 'closed'  then raise exception 'SLOT_CLOSED'; end if;
  if v_state = 'past'    then raise exception 'SLOT_PAST'; end if;

  if (select count(*) from public.reservations where phone = v_phone and status in ('pending','confirmed')
      and (date + end_time) > local_now()) >= s.max_active_per_phone then
    raise exception 'PHONE_LIMIT';
  end if;

  v_id  := nextval(pg_get_serial_sequence('public.reservations', 'id'));
  v_num := 'GRD-' || to_char(local_now(), 'YYYY') || '-' || lpad(v_id::text, 4, '0');
  begin
    insert into public.reservations (id, num, terrain_id, date, start_time, end_time, type, full_name, phone, assoc_name, lang)
    values (v_id, v_num, p_terrain, p_date, v_start, v_end, p_type, v_name, v_phone, v_assoc,
            case when p_lang = 'ar' then 'ar' else 'fr' end);
  exception when exclusion_violation then
    raise exception 'SLOT_TAKEN';     -- deux demandes simultanées : une seule passe
  end;

  insert into public.rate_events (ip, kind) values (v_ip, 'create');
  delete from public.rate_events where at < now() - interval '1 day';

  return json_build_object('num', v_num, 'status', 'pending', 'terrain_id', p_terrain, 'date', p_date,
                           'start_time', to_char(v_start,'HH24:MI'), 'end_time', to_char(v_end,'HH24:MI'));
end $$;

-- 4.5 Suivi : n° de réservation + téléphone → réservations de ce téléphone
create or replace function public.lookup_reservations(p_num text, p_phone text)
returns table (num text, terrain_id smallint, date date, start_time text, end_time text, type text,
               full_name text, assoc_name text, status text, can_cancel boolean, phone_masked text)
language plpgsql volatile security definer set search_path = public as $$
declare v_phone text := norm_phone(p_phone); v_ip text := client_ip(); s public.settings;
begin
  if v_ip <> 'unknown' and (select count(*) from public.rate_events where ip = v_ip and kind = 'lookup_fail' and at > now() - interval '5 minutes') >= 10 then
    raise exception 'LOCKED';
  end if;
  if v_phone is null or not exists (select 1 from public.reservations r
       where upper(r.num) = upper(regexp_replace(coalesce(p_num,''), '\s', '', 'g')) and r.phone = v_phone) then
    -- pas d'exception ici : l'essai raté doit rester enregistré (anti-devinette)
    insert into public.rate_events (ip, kind) values (v_ip, 'lookup_fail');
    return;                                  -- aucun résultat = "introuvable"
  end if;
  select * into s from public.settings limit 1;
  return query
    select r.num, r.terrain_id, r.date, to_char(r.start_time,'HH24:MI'), to_char(r.end_time,'HH24:MI'), r.type,
           r.full_name, r.assoc_name,
           case when r.status = 'confirmed' and (r.date + r.end_time) < local_now() then 'done' else r.status end,
           (r.status in ('pending','confirmed') and (r.date + r.start_time) - local_now() >= make_interval(hours => s.cancel_hours)),
           mask_phone(r.phone)
    from public.reservations r where r.phone = v_phone
    order by r.date desc, r.start_time desc limit 50;
end $$;

-- 4.6 Annulation par le citoyen (selon le délai fixé par la commune)
create or replace function public.cancel_reservation(p_num text, p_phone text)
returns text language plpgsql volatile security definer set search_path = public as $$
declare v_phone text := norm_phone(p_phone); r public.reservations; s public.settings; v_ip text := client_ip();
begin
  if v_ip <> 'unknown' and (select count(*) from public.rate_events where ip = v_ip and kind = 'lookup_fail' and at > now() - interval '5 minutes') >= 10 then
    raise exception 'LOCKED';
  end if;
  select * into r from public.reservations x
   where upper(x.num) = upper(regexp_replace(coalesce(p_num,''), '\s', '', 'g')) and x.phone = v_phone for update;
  if r.id is null then insert into public.rate_events (ip, kind) values (v_ip, 'lookup_fail'); return 'NOT_FOUND'; end if;
  if r.status not in ('pending','confirmed') then raise exception 'NOT_CANCELLABLE'; end if;
  select * into s from public.settings limit 1;
  if (r.date + r.start_time) - local_now() < make_interval(hours => s.cancel_hours) then raise exception 'TOO_LATE'; end if;
  update public.reservations set status = 'cancelled' where id = r.id;
  return 'cancelled';
end $$;

-- ---------------------------------------------------------------------
-- 5. Fonctions d'administration
-- ---------------------------------------------------------------------

-- Passe automatiquement en "Terminée" les réservations confirmées déjà jouées
create or replace function public.admin_mark_done() returns int
language plpgsql volatile security definer set search_path = public as $$
declare n int;
begin
  if not is_admin() then raise exception 'FORBIDDEN'; end if;
  update public.reservations set status = 'done'
   where status = 'confirmed' and (date + end_time) < local_now();
  get diagnostics n = row_count;
  return n;
end $$;

-- Profil de l'utilisateur connecté (null si non autorisé)
create or replace function public.admin_whoami() returns json
language sql stable security definer set search_path = public as $$
  select json_build_object('user_id', user_id, 'display_name', display_name, 'role', role)
  from public.admin_users where user_id = auth.uid()
$$;

-- ---------------------------------------------------------------------
-- 6. Déclencheurs (horodatage, décision, journal)
-- ---------------------------------------------------------------------

create or replace function public.trg_reservation_before() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  new.updated_at := now();
  if tg_op = 'UPDATE' then
    new.num := old.num;                     -- le numéro ne change jamais
    new.created_at := old.created_at;
    if new.status is distinct from old.status and auth.uid() is not null then
      new.decided_by := auth.uid(); new.decided_at := now();
    end if;
    if (new.terrain_id, new.date, new.start_time, new.end_time) is distinct from (old.terrain_id, old.date, old.start_time, old.end_time)
       and new.status in ('pending','confirmed')
       and exists (select 1 from public.blocks b where b.terrain_id = new.terrain_id and b.date = new.date
                   and b.start_time < new.end_time and new.start_time < b.end_time) then
      raise exception 'SLOT_BLOCKED';
    end if;
  end if;
  return new;
end $$;
drop trigger if exists reservation_before on public.reservations;
create trigger reservation_before before update on public.reservations
  for each row execute function public.trg_reservation_before();

create or replace function public.trg_audit() returns trigger
language plpgsql security definer set search_path = public as $$
declare d jsonb; rid text; resid bigint;
begin
  if tg_op = 'INSERT' then
    d := to_jsonb(new) - 'phone'; rid := (to_jsonb(new)->>'id');
  elsif tg_op = 'UPDATE' then
    select jsonb_object_agg(n.key, jsonb_build_array(o.value, n.value)) into d
      from jsonb_each(to_jsonb(new)) n join jsonb_each(to_jsonb(old)) o using (key)
     where n.value is distinct from o.value and n.key not in ('updated_at','decided_at','decided_by');
    if d is null then return new; end if;
    rid := (to_jsonb(new)->>'id');
  else
    d := to_jsonb(old) - 'phone'; rid := (to_jsonb(old)->>'id');
  end if;
  if tg_table_name = 'reservations' then resid := rid::bigint; end if;
  insert into public.audit_log (actor, table_name, op, row_id, reservation_id, data)
  values (auth.uid(), tg_table_name, tg_op, rid, resid, d);
  return coalesce(new, old);
end $$;

drop trigger if exists audit_reservations on public.reservations;
create trigger audit_reservations after insert or update or delete on public.reservations
  for each row execute function public.trg_audit();
drop trigger if exists audit_terrains on public.terrains;
create trigger audit_terrains after insert or update or delete on public.terrains
  for each row execute function public.trg_audit();
drop trigger if exists audit_settings on public.settings;
create trigger audit_settings after update on public.settings
  for each row execute function public.trg_audit();
drop trigger if exists audit_closures on public.closures;
create trigger audit_closures after insert or update or delete on public.closures
  for each row execute function public.trg_audit();
drop trigger if exists audit_blocks on public.blocks;
create trigger audit_blocks after insert or update or delete on public.blocks
  for each row execute function public.trg_audit();

-- ---------------------------------------------------------------------
-- 7. Droits d'accès (Row Level Security)
-- ---------------------------------------------------------------------

alter table public.terrains     enable row level security;
alter table public.settings     enable row level security;
alter table public.closures     enable row level security;
alter table public.blocks       enable row level security;
alter table public.reservations enable row level security;
alter table public.admin_users  enable row level security;
alter table public.audit_log    enable row level security;
alter table public.rate_events  enable row level security;

-- Personne n'a d'accès direct par défaut
revoke all on all tables    in schema public from anon, authenticated;
revoke all on all sequences in schema public from anon, authenticated;
revoke all on all functions in schema public from public, anon, authenticated;

-- Citoyens : uniquement les fonctions publiques
grant execute on function public.get_public_config()                                   to anon, authenticated;
grant execute on function public.get_availability(smallint, date)                      to anon, authenticated;
grant execute on function public.get_calendar(smallint, date, date)                    to anon, authenticated;
grant execute on function public.create_reservation(smallint, date, text, text, text, text, text, text, boolean) to anon, authenticated;
grant execute on function public.lookup_reservations(text, text)                       to anon, authenticated;
grant execute on function public.cancel_reservation(text, text)                        to anon, authenticated;

-- Administration (vérifications internes is_admin / is_superadmin)
grant execute on function public.admin_mark_done() to authenticated;
grant execute on function public.admin_whoami()    to authenticated;
grant execute on function public.is_admin()        to authenticated;
grant execute on function public.is_superadmin()   to authenticated;

grant select, update                 on public.terrains     to authenticated;
grant insert                         on public.terrains     to authenticated;
grant select, update                 on public.settings     to authenticated;
grant select, insert, delete         on public.closures     to authenticated;
grant select, insert, delete         on public.blocks       to authenticated;
grant select, delete                 on public.reservations to authenticated;
grant update (terrain_id, date, start_time, end_time, full_name, phone, assoc_name, status, admin_note)
                                     on public.reservations to authenticated;
grant select                         on public.admin_users  to authenticated;
grant select                         on public.audit_log    to authenticated;
grant usage on all sequences in schema public to authenticated;

drop policy if exists terrains_read   on public.terrains;
drop policy if exists terrains_write  on public.terrains;
drop policy if exists terrains_insert on public.terrains;
create policy terrains_read   on public.terrains for select to authenticated using (public.is_admin());
create policy terrains_write  on public.terrains for update to authenticated using (public.is_superadmin()) with check (public.is_superadmin());
create policy terrains_insert on public.terrains for insert to authenticated with check (public.is_superadmin());

drop policy if exists settings_read  on public.settings;
drop policy if exists settings_write on public.settings;
create policy settings_read  on public.settings for select to authenticated using (public.is_admin());
create policy settings_write on public.settings for update to authenticated using (public.is_superadmin()) with check (public.is_superadmin());

drop policy if exists closures_read  on public.closures;
drop policy if exists closures_write on public.closures;
drop policy if exists closures_del   on public.closures;
create policy closures_read  on public.closures for select to authenticated using (public.is_admin());
create policy closures_write on public.closures for insert to authenticated with check (public.is_superadmin());
create policy closures_del   on public.closures for delete to authenticated using (public.is_superadmin());

drop policy if exists blocks_read  on public.blocks;
drop policy if exists blocks_write on public.blocks;
drop policy if exists blocks_del   on public.blocks;
create policy blocks_read  on public.blocks for select to authenticated using (public.is_admin());
create policy blocks_write on public.blocks for insert to authenticated with check (public.is_admin());
create policy blocks_del   on public.blocks for delete to authenticated using (public.is_admin());

drop policy if exists res_read   on public.reservations;
drop policy if exists res_update on public.reservations;
drop policy if exists res_delete on public.reservations;
create policy res_read   on public.reservations for select to authenticated using (public.is_admin());
create policy res_update on public.reservations for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy res_delete on public.reservations for delete to authenticated using (public.is_superadmin());

drop policy if exists admins_read on public.admin_users;
create policy admins_read on public.admin_users for select to authenticated
  using (user_id = auth.uid() or public.is_superadmin());

drop policy if exists audit_read on public.audit_log;
create policy audit_read on public.audit_log for select to authenticated using (public.is_admin());
-- rate_events : aucune policy => inaccessible

-- ---------------------------------------------------------------------
-- 8. Temps réel : nouvelles demandes visibles immédiatement par l'administration
-- ---------------------------------------------------------------------
do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime')
     and not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime'
                     and schemaname = 'public' and tablename = 'reservations') then
    execute 'alter publication supabase_realtime add table public.reservations';
  end if;
end $$;

-- Fin du schéma.
