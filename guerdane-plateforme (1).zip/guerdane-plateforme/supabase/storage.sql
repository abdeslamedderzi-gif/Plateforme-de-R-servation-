-- =====================================================================
--  Stockage des photos des terrains (Supabase Storage)
--  À exécuter APRÈS schema.sql, dans Supabase > SQL Editor.
--  Les photos sont publiques en lecture ; seul le super-administrateur
--  peut en ajouter, remplacer ou supprimer.
-- =====================================================================
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('terrains', 'terrains', true, 3145728, array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

drop policy if exists "terrains_images_insert" on storage.objects;
drop policy if exists "terrains_images_update" on storage.objects;
drop policy if exists "terrains_images_delete" on storage.objects;
create policy "terrains_images_insert" on storage.objects for insert to authenticated
  with check (bucket_id = 'terrains' and public.is_superadmin());
create policy "terrains_images_update" on storage.objects for update to authenticated
  using (bucket_id = 'terrains' and public.is_superadmin());
create policy "terrains_images_delete" on storage.objects for delete to authenticated
  using (bucket_id = 'terrains' and public.is_superadmin());
