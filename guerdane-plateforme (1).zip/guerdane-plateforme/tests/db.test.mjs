// Tests de la base de données : règles métier, sécurité et anti double-réservation.
// Lancer : npm run test:db
import assert from 'node:assert/strict';
import { createDb, as, ADMIN_ID, AGENT_ID, STRANGER_ID, localToday, addDays } from './supabase-sim.mjs';

const db = await createDb();
const D1 = addDays(localToday(), 1), D2 = addDays(localToday(), 2), D3 = addDays(localToday(), 3);
let pass = 0; const results = [];
async function test(name, fn) {
  try { await fn(); pass++; results.push(['OK', name]); }
  catch (e) { results.push(['ÉCHEC', name + ' → ' + e.message]); }
}
async function rejects(p, code) {
  try { await p; } catch (e) { assert.match(e.message, new RegExp(code)); return; }
  throw new Error('aurait dû être refusé : ' + code);
}
const create = (args, ip) => as(db, 'anon',
  `select public.create_reservation($1::smallint,$2::date,$3,$4,$5,$6,$7,$8,$9) as r`,
  [args.t ?? 1, args.d ?? D1, args.s ?? '19:00', args.type ?? 'indiv', args.name ?? 'TEST Citoyen',
   args.phone ?? '0600000001', args.assoc ?? null, args.lang ?? 'fr', args.consent ?? true], ip).then(r => r[0].r);

let first;
await test('1. Un citoyen crée une demande (statut En attente, numéro unique)', async () => {
  first = await create({});
  assert.equal(first.status, 'pending');
  assert.match(first.num, /^GRD-\d{4}-\d{4}$/);
});
await test('6a. Le même créneau ne peut pas être réservé deux fois', async () => {
  await rejects(create({ phone: '0600000009', name: 'TEST Autre' }), 'SLOT_TAKEN');
});
await test('6b. Deux demandes simultanées : la contrainte de la base en refuse une', async () => {
  await db.exec(`insert into public.reservations (num,terrain_id,date,start_time,end_time,type,full_name,phone)
                 values ('X1',1,'${D3}','20:00','21:00','indiv','TEST A','0600000010')`);
  await rejects(db.exec(`insert into public.reservations (num,terrain_id,date,start_time,end_time,type,full_name,phone)
                 values ('X2',1,'${D3}','20:30','21:30','indiv','TEST B','0600000011')`), 'no_double_booking');
  await db.exec(`delete from public.reservations where num='X1'`);
});
await test('7. Terrain 1 et Terrain 2 sont indépendants (même heure possible)', async () => {
  const r = await create({ t: 2, phone: '0600000002', type: 'assoc', assoc: 'TEST Association', name: 'TEST Responsable' });
  assert.equal(r.status, 'pending');
});
await test('Créneau réservé affiché comme indisponible', async () => {
  const a = await as(db, 'anon', `select * from public.get_availability(1::smallint, $1::date)`, [D1]);
  assert.equal(a.length, 5);
  assert.equal(a.find(x => x.start_time === '19:00').state, 'taken');
  assert.equal(a.find(x => x.start_time === '18:00').state, 'free');
  assert.ok(!JSON.stringify(a).includes('0600'), 'aucun téléphone exposé');
});
await test('Téléphone obligatoire et au format marocain', async () => {
  await rejects(create({ s: '20:00', phone: '12345' }), 'BAD_PHONE');
  await rejects(create({ s: '20:00', phone: '' }), 'BAD_PHONE');
  const r = await create({ s: '20:00', phone: '+212 6 00 00 00 05', name: 'TEST Format' });
  assert.equal(r.status, 'pending');
});
await test('Nom complet, consentement et association validés côté serveur', async () => {
  await rejects(create({ s: '21:00', name: 'A' }), 'BAD_NAME');
  await rejects(create({ s: '21:00', name: '<script>x</script>' }), 'BAD_NAME');
  await rejects(create({ s: '21:00', consent: false }), 'NO_CONSENT');
  await rejects(create({ s: '21:00', type: 'assoc', assoc: '' }), 'BAD_ASSOC');
});
await test('Créneau hors horaires ou mal aligné refusé', async () => {
  await rejects(create({ s: '17:00' }), 'BAD_SLOT');
  await rejects(create({ s: '19:30' }), 'BAD_SLOT');
  await rejects(create({ s: '23:00' }), 'BAD_SLOT');
});
await test('Date passée ou trop lointaine refusée', async () => {
  await rejects(create({ d: addDays(localToday(), -1) }), 'SLOT_PAST');
  await rejects(create({ d: addDays(localToday(), 60) }), 'SLOT_CLOSED');
});
await test('Limite de 3 demandes actives par téléphone', async () => {
  await create({ d: D2, s: '18:00', phone: '0600000077', name: 'TEST Lim' });
  await create({ d: D2, s: '19:00', phone: '0600000077', name: 'TEST Lim' });
  await create({ d: D2, s: '20:00', phone: '0600000077', name: 'TEST Lim' });
  await rejects(create({ d: D2, s: '21:00', phone: '0600000077', name: 'TEST Lim' }), 'PHONE_LIMIT');
});
await test('10. Le citoyen n’a aucun accès direct aux tables', async () => {
  for (const t of ['reservations', 'terrains', 'settings', 'blocks', 'audit_log', 'admin_users']) {
    await rejects(as(db, 'anon', `select * from public.${t}`), 'permission denied');
  }
  await rejects(as(db, 'anon', `update public.reservations set status='confirmed'`), 'permission denied');
  await rejects(as(db, 'anon', `select public.admin_mark_done()`), 'permission denied');
});
await test('10b. Un compte connecté mais non autorisé ne voit rien', async () => {
  const r = await as(db, STRANGER_ID, `select * from public.reservations`);
  assert.equal(r.length, 0);
  const u = await as(db, STRANGER_ID, `update public.reservations set status='confirmed' returning id`);
  assert.equal(u.length, 0);
});
await test('2. La demande apparaît dans la liste de l’administration', async () => {
  const r = await as(db, AGENT_ID, `select num, phone, status from public.reservations where num=$1`, [first.num]);
  assert.equal(r.length, 1); assert.equal(r[0].phone, '0600000001');
});
await test('3. L’administration accepte une demande', async () => {
  const r = await as(db, AGENT_ID, `update public.reservations set status='confirmed' where num=$1 returning status, decided_by`, [first.num]);
  assert.equal(r[0].status, 'confirmed'); assert.equal(r[0].decided_by, AGENT_ID);
});
let second;
await test('4. L’administration refuse une demande (le créneau redevient libre)', async () => {
  second = await create({ t: 1, d: D1, s: '22:00', phone: '0600000003', name: 'TEST Refus' });
  await as(db, ADMIN_ID, `update public.reservations set status='refused' where num=$1`, [second.num]);
  const a = await as(db, 'anon', `select * from public.get_availability(1::smallint, $1::date)`, [D1]);
  assert.equal(a.find(x => x.start_time === '22:00').state, 'free');
});
await test('5. Le citoyen voit le nouveau statut (Acceptée / Refusée)', async () => {
  const r1 = await as(db, 'anon', `select * from public.lookup_reservations($1,$2)`, [first.num, '06 00 00 00 01']);
  assert.equal(r1[0].status, 'confirmed'); assert.equal(r1[0].phone_masked, '06 ** ** 00 01');
  const r2 = await as(db, 'anon', `select * from public.lookup_reservations($1,$2)`, [second.num.toLowerCase(), '0600000003']);
  assert.equal(r2[0].status, 'refused');
});
await test('Suivi refusé si le numéro et le téléphone ne correspondent pas', async () => {
  const r = await as(db, 'anon', `select * from public.lookup_reservations($1,$2)`, [first.num, '0699999999'], '10.0.0.50');
  assert.equal(r.length, 0);
});
await test('Blocage après 10 essais incorrects (anti-devinette)', async () => {
  for (let i = 0; i < 9; i++) assert.equal((await as(db, 'anon', `select * from public.lookup_reservations('GRD-0000-0000','0600000001')`, [], '10.0.0.50')).length, 0);
  await rejects(as(db, 'anon', `select * from public.lookup_reservations($1,$2)`, [first.num, '0600000001'], '10.0.0.50'), 'LOCKED');
  const ok = await as(db, 'anon', `select * from public.lookup_reservations($1,$2)`, [first.num, '0600000001'], '10.0.0.51');
  assert.ok(ok.length >= 1);
});
await test('Annulation par le citoyen avant le délai', async () => {
  const r = await create({ t: 2, d: D3, s: '22:00', phone: '0600000004', name: 'TEST Annul' });
  const c = await as(db, 'anon', `select public.cancel_reservation($1,$2) as s`, [r.num, '0600000004']);
  assert.equal(c[0].s, 'cancelled');
  await rejects(as(db, 'anon', `select public.cancel_reservation($1,$2)`, [r.num, '0600000004']), 'NOT_CANCELLABLE');
});
await test('Créneau bloqué et fermeture temporaire d’un terrain', async () => {
  await as(db, AGENT_ID, `insert into public.blocks (terrain_id,date,start_time,end_time,reason) values (2,$1,'18:00','19:00','Entretien')`, [D2]);
  await rejects(create({ t: 2, d: D2, s: '18:00', phone: '0600000020' }), 'SLOT_BLOCKED');
  const u = await as(db, AGENT_ID, `update public.terrains set active=false where id=2 returning id`);
  assert.equal(u.length, 0, 'un simple administrateur ne peut pas fermer un terrain');
  await as(db, ADMIN_ID, `update public.terrains set active=false, closed_reason='Maintenance' where id=2`);
  await rejects(create({ t: 2, d: D2, s: '20:00', phone: '0600000021' }), 'SLOT_CLOSED');
  await as(db, ADMIN_ID, `update public.terrains set active=true, closed_reason=null where id=2`);
});
await test('Jours de fermeture exceptionnels', async () => {
  await as(db, ADMIN_ID, `insert into public.closures (terrain_id,date_from,date_to,reason) values (null,$1,$1,'Fête')`, [D3]);
  await rejects(create({ t: 1, d: D3, s: '18:00', phone: '0600000030' }), 'SLOT_CLOSED');
  const cal = await as(db, 'anon', `select * from public.get_calendar(1::smallint,$1::date,$2::date)`, [D1, D3]);
  assert.equal(cal.find(c => c.day.toISOString?.().slice(0,10) === D3 || String(c.day).startsWith(D3) || c.day === D3)?.free_count ?? cal[cal.length-1].free_count, 0);
});
await test('Suppression réservée au super-administrateur', async () => {
  const del1 = await as(db, AGENT_ID, `delete from public.reservations where num=$1 returning id`, [second.num]);
  assert.equal(del1.length, 0);
  const del2 = await as(db, ADMIN_ID, `delete from public.reservations where num=$1 returning id`, [second.num]);
  assert.equal(del2.length, 1);
});
await test('Modification d’horaire par l’administration contrôlée (conflits refusés)', async () => {
  const r = await create({ t: 1, d: D2, s: '22:00', phone: '0600000040', name: 'TEST Modif' });
  await rejects(as(db, ADMIN_ID, `update public.reservations set start_time='18:00', end_time='19:00' where num=$1`, [r.num]), 'no_double_booking');
  await as(db, ADMIN_ID, `update public.reservations set num='HACK' where num=$1`, [r.num]).then(() => { throw new Error('num modifiable') }, e => assert.match(e.message, /permission/));
});
await test('Journal des opérations alimenté automatiquement', async () => {
  const j = await as(db, ADMIN_ID, `select count(*)::int n from public.audit_log where table_name='reservations'`);
  assert.ok(j[0].n > 5);
  const p = await as(db, ADMIN_ID, `select data from public.audit_log where op='INSERT' and table_name='reservations' limit 1`);
  assert.ok(!('phone' in p[0].data), 'le journal ne copie pas le téléphone à la création');
});
await test('Anti-abus : 30 demandes par heure et par adresse IP', async () => {
  const ip = '10.9.9.9';
  for (let i = 0; i < 30; i++) {
    try { await create({ t: 1 + (i % 2), d: addDays(localToday(), 5 + Math.floor(i / 2)), s: '18:00', phone: '06100000' + String(i).padStart(2, '0'), name: 'TEST Flood' }, ip); } catch (e) { }
  }
  await rejects(create({ t: 2, d: addDays(localToday(), 20), s: '18:00', phone: '0610000099', name: 'TEST Flood' }, ip), 'RATE_LIMIT');
});
await test('Passage automatique en "Terminée" (admin)', async () => {
  await db.exec(`insert into public.reservations (num,terrain_id,date,start_time,end_time,type,full_name,phone,status)
                 values ('OLD1',1,'${addDays(localToday(), -3)}','18:00','19:00','indiv','TEST Ancien','0600000050','confirmed')`);
  const n = await as(db, AGENT_ID, `select public.admin_mark_done() as n`);
  assert.ok(n[0].n >= 1);
});

for (const [s, n] of results) console.log(`${s === 'OK' ? '✔' : '✘'} ${n}`);
console.log(`\n${pass}/${results.length} tests réussis`);
process.exit(pass === results.length ? 0 : 1);
