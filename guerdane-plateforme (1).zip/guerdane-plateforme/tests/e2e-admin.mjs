// Scénarios de l'espace administration (appelés par e2e.test.mjs)
import assert from 'node:assert/strict';

export async function run({ loadPage, test, db, ticket, sleep }) {
  const login = async (P, email, pw) => {
    await P.until(() => P.d.getElementById('loginF'));
    P.d.getElementById('lu').value = email; P.d.getElementById('lp').value = pw;
    await P.submit('loginF'); await sleep(80);
  };

  await test('10. Protection : mauvais mot de passe refusé', async () => {
    const P = loadPage('admin/index.html', '');
    await login(P, 'agent@test.ma', 'mauvais');
    await P.until(() => P.d.querySelector('.err'));
    assert.match(P.d.querySelector('.err').textContent, /incorrect/);
    assert.ok(!P.d.querySelector('.side'));
  });
  await test('10b. Protection : compte connecté mais non inscrit comme administrateur → refusé', async () => {
    const P = loadPage('admin/index.html', '');
    await login(P, 'inconnu@test.ma', 'Inconnu2026!');
    await P.until(() => P.d.querySelector('.err'));
    assert.match(P.d.querySelector('.err').textContent, /pas accès/);
  });
  await test('10c. Aucun mot de passe ni clé secrète dans les fichiers du navigateur', async () => {
    const { readFileSync } = await import('node:fs');
    for (const f of ['public/js/admin.js', 'public/js/common.js', 'public/js/config.js', 'public/admin/index.html']) {
      const s = readFileSync(new URL('../' + f, import.meta.url), 'utf8');
      assert.ok(!/service_role|guerdan2026|Admin2026|sha256\(/i.test(s.replace(/Ne mettez JAMAIS ici la clé "service_role"/, '')), f);
    }
  });

  let P;
  await test('2. La demande du citoyen apparaît dans le tableau de bord', async () => {
    P = loadPage('admin/index.html', '');
    await login(P, 'agent@test.ma', 'Agent2026!');
    await P.until(() => P.d.querySelector('.dhero'));
    const { ticket1 } = ticket();
    assert.ok(P.w.__admin.D.res.some((r) => r.num === ticket1));
    assert.ok(P.d.querySelectorAll('.pc').length >= 1, 'liste "Demandes à traiter"');
    assert.deepEqual(P.errors, []);
  });
  await test('Temps réel : une nouvelle demande s’affiche sans recharger', async () => {
    const before = P.w.__admin.D.res.length;
    const row = (await db.query(`select to_json(r) j from public.reservations r order by id desc limit 1`)).rows[0].j;
    P.w.__client.__emit({ eventType: 'INSERT', new: Object.assign({}, row, { id: 999999, num: 'GRD-TEST-RT' }) });
    await sleep(30);
    assert.equal(P.w.__admin.D.res.length, before + 1);
    assert.match(P.d.getElementById('toast').textContent, /GRD-TEST-RT/);
    P.w.__admin.D.res = P.w.__admin.D.res.filter((r) => r.id !== 999999);
  });
  await test('3. Accepter une demande (statut mis à jour dans la base)', async () => {
    const { ticket1 } = ticket();
    await P.click('[data-act=tab][data-v=res]');
    const r = P.w.__admin.D.res.find((x) => x.num === ticket1);
    await P.click(`[data-act=setSt][data-id="${r.id}"][data-v=confirmed]`);
    await P.until(() => P.w.__admin.D.res.find((x) => x.num === ticket1).status === 'confirmed');
    const db1 = (await db.query(`select status from public.reservations where num=$1`, [ticket1])).rows[0];
    assert.equal(db1.status, 'confirmed');
  });
  await test('4. Refuser une demande (avec confirmation)', async () => {
    const { ticket2 } = ticket();
    const r = P.w.__admin.D.res.find((x) => x.num === ticket2);
    await P.click(`[data-act=askSt][data-id="${r.id}"][data-v=refused]`);
    await P.click(`#mbox [data-act=setSt][data-v=refused]`);
    await P.until(() => P.w.__admin.D.res.find((x) => x.num === ticket2).status === 'refused');
  });
  await test('5. Le citoyen voit "Acceptée" et "Refusée"', async () => {
    const { ticket1, ticket2 } = ticket();
    for (const [num, phone, re] of [[ticket1, '0600000101', /Acceptée/], [ticket2, '0600000102', /Refusée/]]) {
      const C = loadPage('index.html', '#consult');
      await C.until(() => C.d.getElementById('cnum'));
      C.type('cnum', num); C.type('cphone', phone); await C.submit('consF');
      await C.until(() => C.d.querySelector('.ritem'));
      assert.match(C.d.querySelector('.ritem').textContent, re);
    }
  });
  await test('Recherche par nom / téléphone et filtres', async () => {
    const s = P.d.getElementById('q'); s.value = '0600000102'; s.dispatchEvent(new P.w.Event('input', { bubbles: true }));
    assert.equal(P.d.querySelectorAll('#resList tbody tr').length, 1);
    s.value = 'TEST Citoyen Un'; s.dispatchEvent(new P.w.Event('input', { bubbles: true }));
    assert.equal(P.d.querySelectorAll('#resList tbody tr').length, 1);
    await P.click('[data-act=fReset]');
    const sel = P.d.querySelector('[data-f=fStatus]'); sel.value = 'refused'; sel.dispatchEvent(new P.w.Event('change', { bubbles: true })); await sleep(20);
    assert.ok([...P.d.querySelectorAll('#resList tbody tr')].every((tr) => /Refusée/.test(tr.textContent)));
    await P.click('[data-act=fReset]');
  });
  await test('Détails et historique d’une réservation', async () => {
    const { ticket1 } = ticket(); const r = P.w.__admin.D.res.find((x) => x.num === ticket1);
    await P.click(`[data-act=openRes][data-id="${r.id}"]`);
    assert.match(P.d.getElementById('mbox').textContent, /06 00 00 01 01/);
    await P.click('#mbox [data-act=hist]');
    await P.until(() => /Acceptée/.test(P.d.getElementById('mbox').textContent));
    P.w.document.querySelector('#modal').classList.remove('on');
  });
  await test('Administrateur simple : pas de suppression ni de paramètres', async () => {
    await P.click('[data-act=tab][data-v=terr]');
    assert.ok(P.d.querySelector('[data-act=saveT]').disabled);
    const { ticket1 } = ticket(); const r = P.w.__admin.D.res.find((x) => x.num === ticket1);
    await P.click('[data-act=tab][data-v=res]'); await P.click(`[data-act=openRes][data-id="${r.id}"]`);
    assert.ok(!P.d.querySelector('#mbox [data-act=askDel]'));
    P.w.document.querySelector('#modal').classList.remove('on');
  });
  await test('Planning jour / semaine / mois', async () => {
    await P.click('[data-act=tab][data-v=plan]');
    for (const v of ['day', 'month', 'week']) { await P.click(`[data-act=pView][data-v=${v}]`); assert.ok(P.d.querySelector('.pg,.mgrid')); }
    assert.ok(P.d.querySelector('.chip'));
  });
  await test('Rapports et journal', async () => {
    await P.click('[data-act=tab][data-v=rep]'); assert.match(P.d.getElementById('printArea').textContent, /Total des demandes/);
    await P.click('[data-act=tab][data-v=log]'); await P.until(() => P.d.querySelector('table.stack'));
    assert.match(P.d.querySelector('table.stack').textContent, /Réservation/);
    assert.deepEqual(P.errors, []);
  });

  let S;
  await test('Super-administrateur : fermer temporairement le Terrain 2 (visible côté citoyen)', async () => {
    S = loadPage('admin/index.html', '');
    await login(S, 'responsable@test.ma', 'Admin2026!');
    await S.until(() => S.d.querySelector('.dhero'));
    await S.click('[data-act=tab][data-v=terr]');
    S.d.getElementById('tf2_a').checked = false; S.d.getElementById('tf2_r').value = 'Maintenance du gazon';
    await S.click('[data-act=saveT][data-id="2"]'); await sleep(60);
    const C = loadPage('index.html', '#home');
    await C.until(() => C.d.querySelector('.tc2'));
    assert.match(C.d.body.textContent, /Maintenance du gazon/);
    S.d.getElementById('tf2_a').checked = true; S.d.getElementById('tf2_r').value = '';
    await S.click('[data-act=saveT][data-id="2"]'); await sleep(60);
  });
  await test('Contrôle des horaires : bloquer un créneau', async () => {
    const opt = S.d.getElementById('bS'); const first = opt.options[opt.options.length - 1].value;
    const day = S.w.G.ymd(S.w.G.addDays(S.w.G.now(), 4));
    S.d.getElementById('bD').value = day; S.d.getElementById('bS').value = first; S.d.getElementById('bR').value = 'Événement';
    await S.click('[data-act=addBlock]'); await sleep(60);
    const a = (await db.query(`select * from public.get_availability(1::smallint, $1::date)`, [day])).rows;
    assert.equal(a.find((x) => x.start_time === first).state, 'blocked');
  });
  await test('Règles modifiables sans développeur (délai d’annulation)', async () => {
    await S.click('[data-act=tab][data-v=rules]');
    S.d.getElementById('r_can').value = '12'; await S.click('[data-act=saveRules]'); await sleep(60);
    assert.equal((await db.query('select cancel_hours from public.settings')).rows[0].cancel_hours, 12);
  });
  await test('Suppression d’une réservation par le super-administrateur', async () => {
    const { ticket2 } = ticket(); const r = S.w.__admin.D.res.find((x) => x.num === ticket2);
    await S.click('[data-act=tab][data-v=res]'); await S.click(`[data-act=openRes][data-id="${r.id}"]`);
    await S.click('#mbox [data-act=askDel]'); await S.click('#mbox [data-act=doDel]'); await sleep(60);
    assert.equal((await db.query('select count(*)::int n from public.reservations where num=$1', [ticket2])).rows[0].n, 0);
  });
  await test('Changement du mot de passe administrateur', async () => {
    await S.click('[data-act=tab][data-v=account]');
    S.d.getElementById('a_cur').value = 'Admin2026!'; S.d.getElementById('a_p1').value = 'court'; S.d.getElementById('a_p2').value = 'court';
    await S.submit('accF'); await sleep(40); assert.ok(S.d.querySelector('.err'));
    S.d.getElementById('a_cur').value = 'Admin2026!'; S.d.getElementById('a_p1').value = 'NouveauPass2027'; S.d.getElementById('a_p2').value = 'NouveauPass2027';
    await S.submit('accF'); await sleep(80);
    assert.match(S.d.getElementById('toast').textContent, /modifié/);
    await S.click('[data-act=logout]');
    await login(S, 'responsable@test.ma', 'Admin2026!'); await S.until(() => S.d.querySelector('.err'));
    await login(S, 'responsable@test.ma', 'NouveauPass2027'); await S.until(() => S.d.querySelector('.dhero'));
  });
  await test('8b. Administration en arabe (RTL)', async () => {
    await S.click('[data-act=lang]');
    assert.equal(S.d.documentElement.dir, 'rtl');
    assert.match(S.d.querySelector('.side').textContent, /لوحة القيادة/);
    assert.deepEqual(S.errors, []);
  });
}
