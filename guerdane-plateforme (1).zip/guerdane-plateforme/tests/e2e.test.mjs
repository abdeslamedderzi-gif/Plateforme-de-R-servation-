// Tests bout en bout : les vraies pages (public/) dans un navigateur simulé (jsdom),
// branchées sur le vrai schéma PostgreSQL. Lancer : npm run test:e2e
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { JSDOM } from 'jsdom';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { createDb, ADMIN_ID, AGENT_ID, STRANGER_ID, localToday, addDays } from './supabase-sim.mjs';
import { makeClientFactory } from './mock-client.mjs';

const root = join(dirname(fileURLToPath(import.meta.url)), '..', 'public');
const db = await createDb();
const users = [
  { id: ADMIN_ID, email: 'responsable@test.ma', password: 'Admin2026!' },
  { id: AGENT_ID, email: 'agent@test.ma', password: 'Agent2026!' },
  { id: STRANGER_ID, email: 'inconnu@test.ma', password: 'Inconnu2026!' }
];
const factory = makeClientFactory(db, users);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function loadPage(rel, hash, { width = 1280, lang = 'fr' } = {}) {
  let html = readFileSync(join(root, rel), 'utf8');
  const base = rel.includes('/') ? '../' : '';
  html = html.replace(/<script src="([^"]+)"><\/script>/g, (_, src) => {
    if (src.includes('vendor/supabase')) return '<script>window.supabase={createClient:(...a)=>window.__factory(...a)};</script>';
    if (src.includes('config.js')) return `<script>window.APP_CONFIG={SUPABASE_URL:'https://test.supabase.co',SUPABASE_ANON_KEY:'cle-publique-test'};</script>`;
    return '<script>' + readFileSync(join(root, rel.includes('/') ? 'admin' : '', src), 'utf8') + '</script>';
  });
  const dom = new JSDOM(html, {
    url: 'https://terrains.exemple.ma/' + (base ? 'admin/' : '') + hash, runScripts: 'dangerously', pretendToBeVisual: true,
    beforeParse(w) {
      w.__factory = (...a) => { const c = factory(...a); w.__client = c; return c; };
      w.scrollTo = () => {}; w.innerWidth = width;
      try { w.localStorage.setItem('grd_lang', lang); } catch (e) {}
    }
  });
  const w = dom.window, d = w.document, errors = [];
  w.addEventListener('error', (e) => errors.push(e.message));
  const until = async (fn, ms = 4000) => { const t0 = Date.now(); while (Date.now() - t0 < ms) { try { const v = fn(); if (v) return v; } catch (e) {} await sleep(20); } throw new Error('délai dépassé'); };
  const click = async (sel) => { const el = await until(() => d.querySelector(sel)); el.click(); await sleep(30); };
  const type = (id, v) => { const e = d.getElementById(id); e.value = v; e.dispatchEvent(new w.Event('input', { bubbles: true })); };
  const check = (id) => { const e = d.getElementById(id); e.checked = true; e.dispatchEvent(new w.Event('input', { bubbles: true })); };
  const submit = async (id) => { d.getElementById(id).dispatchEvent(new w.Event('submit', { bubbles: true, cancelable: true })); await sleep(30); };
  const go = async (h) => { w.location.hash = h; w.dispatchEvent(new w.HashChangeEvent('hashchange')); await sleep(30); };
  return { w, d, errors, until, click, type, check, submit, go };
}

let pass = 0; const results = [];
async function test(name, fn) {
  try { await fn(); pass++; results.push(['OK', name]); }
  catch (e) { results.push(['ÉCHEC', name + ' → ' + e.message]); }
}

/* ===================== ESPACE CITOYENS ===================== */
let ticket1, ticket2;
async function bookVia(P, { terrainIdx = 0, slotIdx = 0, type = 'indiv', name = 'TEST Citoyen', phone = '0600000101', assoc = '' } = {}) {
  await P.go('#book');
  if (P.d.querySelector('[data-act=newRes]')) await P.click('[data-act=newRes]');
  await P.until(() => P.d.querySelectorAll('[data-act=pickT]').length);
  P.d.querySelectorAll('[data-act=pickT]')[terrainIdx].click();
  await P.click('[data-act=pickD]:not([disabled])');
  await P.until(() => P.d.querySelectorAll('[data-act=pickS]:not([disabled])').length > slotIdx);
  P.d.querySelectorAll('[data-act=pickS]:not([disabled])')[slotIdx].click(); await sleep(20);
  if (type === 'assoc') { await P.click('[data-act=type][data-v=assoc]'); P.type('f_assoc', assoc); }
  P.type('f_name', name); P.type('f_phone', phone); P.check('f_consent');
  await P.submit('infoF');
  await P.click('[data-act=submit]');
  return P.until(() => P.d.querySelector('.tk-num')?.textContent);
}

await test('Accueil : chargement, tableau "Ce soir" et aucun lien vers l’administration', async () => {
  const P = loadPage('index.html', '#home');
  await P.until(() => P.d.querySelector('.sbs'));
  assert.ok(!P.d.querySelector('a[href*="admin"]'));
  assert.equal(P.d.querySelectorAll('.tc2').length, 2);
  assert.deepEqual(P.errors, []);
});
await test('1 + 7. Réservation complète sur le Terrain 1 puis sur le Terrain 2', async () => {
  const P = loadPage('index.html', '#book');
  ticket1 = await bookVia(P, { terrainIdx: 0, phone: '0600000101', name: 'TEST Citoyen Un' });
  assert.match(ticket1, /^GRD-\d{4}-\d{4}$/);
  assert.ok(P.d.querySelector('.ticket .badge.b-pending'));
  ticket2 = await bookVia(P, { terrainIdx: 1, type: 'assoc', assoc: 'TEST Association', name: 'TEST Responsable', phone: '0600000102' });
  assert.notEqual(ticket1, ticket2);
  assert.deepEqual(P.errors, []);
});
await test('Validation du formulaire (téléphone obligatoire et format)', async () => {
  const P = loadPage('index.html', '#book');
  await P.until(() => P.d.querySelectorAll('[data-act=pickT]').length);
  P.d.querySelector('[data-act=pickT]').click();
  await P.click('[data-act=pickD]:not([disabled])');
  await P.click('[data-act=pickS]:not([disabled])');
  P.type('f_name', 'TEST Format'); P.type('f_phone', '12345'); P.check('f_consent');
  await P.submit('infoF');
  assert.match(P.d.querySelector('.err').textContent, /invalide/);
  P.type('f_phone', ''); await P.submit('infoF');
  assert.match(P.d.querySelector('.err').textContent, /obligatoire/);
});
await test('6. Le créneau réservé disparaît des horaires libres', async () => {
  const P = loadPage('index.html', '#book');
  await P.until(() => P.d.querySelectorAll('[data-act=pickT]').length);
  P.d.querySelector('[data-act=pickT]').click();
  await P.click('[data-act=pickD]:not([disabled])');
  await P.until(() => P.d.querySelectorAll('.slot').length);
  const taken = [...P.d.querySelectorAll('.slot')].filter((b) => b.disabled).length;
  assert.ok(taken >= 1, 'au moins un créneau indisponible');
});
await test('6b. Double réservation : si un autre citoyen prend le créneau entre-temps, la demande est refusée', async () => {
  const P1 = loadPage('index.html', '#book'), P2 = loadPage('index.html', '#book');
  for (const P of [P1, P2]) {
    await P.until(() => P.d.querySelectorAll('[data-act=pickT]').length);
    P.d.querySelectorAll('[data-act=pickT]')[1].click();
    await P.click('[data-act=pickD]:not([disabled])');
    await P.click('[data-act=pickS]:not([disabled])');
    P.type('f_name', 'TEST Course'); P.type('f_phone', P === P1 ? '0600000103' : '0600000104'); P.check('f_consent');
    await P.submit('infoF');
  }
  await P1.click('[data-act=submit]'); await P1.until(() => P1.d.querySelector('.tk-num'));
  await P2.click('[data-act=submit]');
  await P2.until(() => P2.d.querySelector('#toast .err'));
  assert.match(P2.d.querySelector('#toast .err').textContent, /vient d'être réservé/);
  assert.equal(P2.w.__citizen.B.step, 3, 'retour au choix de l’horaire');
});
await test('5. Suivi : numéro + téléphone → statut En attente', async () => {
  const P = loadPage('index.html', '#consult');
  await P.until(() => P.d.getElementById('cnum'));
  P.type('cnum', ticket1.toLowerCase()); P.type('cphone', '06 00 00 01 01'); await P.submit('consF');
  await P.until(() => P.d.querySelector('.ritem'));
  assert.ok(P.d.querySelector('.ritem .b-pending'));
  assert.match(P.d.body.textContent, /06 \*\* \*\* 01 01/);
});
await test('Suivi avec un mauvais téléphone → introuvable', async () => {
  const P = loadPage('index.html', '#consult');
  await P.until(() => P.d.getElementById('cnum'));
  P.type('cnum', ticket1); P.type('cphone', '0699999998'); await P.submit('consF');
  await P.until(() => P.d.querySelector('.err'));
  assert.match(P.d.querySelector('.err').textContent, /Aucune réservation/);
});
await test('8. Arabe (RTL) et français (LTR)', async () => {
  const P = loadPage('index.html', '#home', { lang: 'ar' });
  await P.until(() => P.d.querySelector('.night h1'));
  assert.equal(P.d.documentElement.dir, 'rtl');
  assert.match(P.d.querySelector('.night h1').textContent, /احجز ملعبك/);
  await P.click('[data-act=lang]');
  assert.equal(P.d.documentElement.dir, 'ltr');
  assert.match(P.d.querySelector('.night h1').textContent, /Réservez votre terrain/);
});

/* ===================== ESPACE ADMINISTRATION ===================== */
const adminTests = await import('./e2e-admin.mjs').catch(() => null);
if (adminTests) await adminTests.run({ loadPage, test, db, ticket: () => ({ ticket1, ticket2 }), sleep });

/* ===================== 11. Aucune fonction SMS / OTP ===================== */
await test('11. Aucun SMS ni OTP dans le code livré', async () => {
  const files = ['index.html', 'admin/index.html', 'js/citizen.js', 'js/admin.js', 'js/common.js'].filter((f) => { try { readFileSync(join(root, f)); return true; } catch (e) { return false; } });
  for (const f of files) {
    const s = readFileSync(join(root, f), 'utf8');
    assert.ok(!/sendOtp|checkOtp|one-time-code|twilio|infobip|sms\.to|envoisms/i.test(s), f);
  }
  const sql = readFileSync(join(root, '..', 'supabase', 'schema.sql'), 'utf8');
  assert.ok(!/otp|sms_|twilio/i.test(sql.replace(/Aucun SMS, aucun OTP/g, '')));
});

for (const [s, n] of results) console.log(`${s === 'OK' ? '✔' : '✘'} ${n}`);
console.log(`\n${pass}/${results.length} tests réussis`);
process.exit(pass === results.length ? 0 : 1);
