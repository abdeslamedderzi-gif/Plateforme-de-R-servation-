// Faux client supabase-js branché sur le vrai schéma PostgreSQL (PGlite).
// Reproduit le comportement de PostgREST : rôles anon / authenticated, RLS,
// fonctions RPC, et un sous-ensemble du "query builder" utilisé par l'admin.
import { as } from './supabase-sim.mjs';

const SETOF = new Set(['get_availability', 'get_calendar', 'lookup_reservations']);

export function makeClientFactory(db, users) {
  return function createClient() {
    let session = null;               // { user: {id,email} }
    const listeners = [];
    const who = () => (session ? session.user.id : 'anon');
    const wrap = async (fn) => { try { return { data: await fn(), error: null }; } catch (e) { return { data: null, error: { message: e.message, code: e.code } }; } };

    async function rpc(name, args = {}) {
      const keys = Object.keys(args);
      const call = `public.${name}(${keys.map((k, i) => `${k} => $${i + 1}`).join(', ')})`;
      const sql = SETOF.has(name) ? `select coalesce(json_agg(r), '[]'::json) as j from ${call} r` : `select to_json(${call}) as j`;
      return wrap(async () => (await as(db, who(), sql, keys.map((k) => args[k])))[0].j);
    }

    function from(table) {
      const st = { op: 'select', cols: '*', where: [], params: [], order: [], limit: null, range: null, values: null, returning: false, single: false };
      const p = (v) => { st.params.push(v); return '$' + st.params.length; };
      const b = {
        select(cols = '*') { if (st.op === 'select') st.cols = cols; else st.returning = true; return b; },
        insert(v) { st.op = 'insert'; st.values = Array.isArray(v) ? v : [v]; return b; },
        update(v) { st.op = 'update'; st.values = v; return b; },
        delete() { st.op = 'delete'; return b; },
        eq(c, v) { st.where.push(`${c} = ${p(v)}`); return b; },
        neq(c, v) { st.where.push(`${c} <> ${p(v)}`); return b; },
        gte(c, v) { st.where.push(`${c} >= ${p(v)}`); return b; },
        lte(c, v) { st.where.push(`${c} <= ${p(v)}`); return b; },
        in(c, arr) { st.where.push(`${c} = any(${p(arr)})`); return b; },
        order(c, o = {}) { st.order.push(`${c} ${o.ascending === false ? 'desc' : 'asc'}`); return b; },
        limit(n) { st.limit = n; return b; },
        range(a, z) { st.range = [a, z]; return b; },
        single() { st.single = true; return b; },
        maybeSingle() { st.single = true; return b; },
        then(res, rej) { return run().then(res, rej); }
      };
      async function run() {
        const w = st.where.length ? ' where ' + st.where.join(' and ') : '';
        let sql;
        if (st.op === 'select') {
          sql = `select coalesce(json_agg(x), '[]'::json) as j from (select ${st.cols} from public.${table}${w}${st.order.length ? ' order by ' + st.order.join(',') : ''}${st.range ? ` offset ${st.range[0]} limit ${st.range[1] - st.range[0] + 1}` : ''}${st.limit ? ' limit ' + st.limit : ''}) x`;
        } else if (st.op === 'update') {
          const set = Object.keys(st.values).map((k) => `${k} = ${p(st.values[k])}`).join(', ');
          sql = `with u as (update public.${table} set ${set}${w} returning *) select coalesce(json_agg(u), '[]'::json) as j from u`;
        } else if (st.op === 'delete') {
          sql = `with u as (delete from public.${table}${w} returning *) select coalesce(json_agg(u), '[]'::json) as j from u`;
        } else {
          const cols = Object.keys(st.values[0]);
          const rows = st.values.map((r) => '(' + cols.map((c) => p(r[c])).join(',') + ')').join(',');
          sql = `with u as (insert into public.${table} (${cols.join(',')}) values ${rows} returning *) select coalesce(json_agg(u), '[]'::json) as j from u`;
        }
        const r = await wrap(async () => (await as(db, who(), sql, st.params))[0].j);
        if (!r.error && st.op !== 'select' && !st.returning) r.data = null;
        if (!r.error && st.single) r.data = r.data ? r.data[0] ?? null : null;
        return r;
      }
      return b;
    }

    const auth = {
      async getSession() { return { data: { session }, error: null }; },
      async signInWithPassword({ email, password }) {
        const u = users.find((x) => x.email === email && x.password === password);
        if (!u) return { data: null, error: { message: 'Invalid login credentials' } };
        session = { user: { id: u.id, email: u.email } }; listeners.forEach((f) => f('SIGNED_IN', session));
        return { data: { session }, error: null };
      },
      async signOut() { session = null; listeners.forEach((f) => f('SIGNED_OUT', null)); return { error: null }; },
      async updateUser({ password }) { const u = users.find((x) => x.id === session?.user.id); if (!u) return { error: { message: 'no session' } }; u.password = password; return { data: {}, error: null }; },
      async resetPasswordForEmail() { return { data: {}, error: null }; },
      onAuthStateChange(f) { listeners.push(f); return { data: { subscription: { unsubscribe() {} } } }; }
    };
    const channels = [];
    const channel = () => {
      const ch = { handlers: [], on(_e, _f, h) { ch.handlers.push(h); return ch; }, subscribe(cb) { cb && cb('SUBSCRIBED'); return ch; } };
      channels.push(ch); return ch;
    };
    const storage = { from: () => ({ upload: async () => ({ data: { path: 'x' }, error: null }), getPublicUrl: (p) => ({ data: { publicUrl: 'https://exemple/' + p } }) }) };
    return { rpc, from, auth, channel, removeChannel() {}, storage, __emit: (payload) => channels.forEach((c) => c.handlers.forEach((h) => h(payload))) };
  };
}
