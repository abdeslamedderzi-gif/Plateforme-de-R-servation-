// Simulateur local de Supabase pour les tests : vrai PostgreSQL (PGlite),
// schéma réel (supabase/schema.sql), rôles anon / authenticated et auth.uid().
import { PGlite } from '@electric-sql/pglite';
import { btree_gist } from '@electric-sql/pglite/contrib/btree_gist';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');

export const ADMIN_ID = '11111111-1111-1111-1111-111111111111';   // super-administrateur
export const AGENT_ID = '22222222-2222-2222-2222-222222222222';   // administrateur simple
export const STRANGER_ID = '33333333-3333-3333-3333-333333333333'; // compte connecté mais non autorisé

export async function createDb() {
  const db = new PGlite({ extensions: { btree_gist } });
  await db.exec(`
    create role anon nologin; create role authenticated nologin;
    create schema auth;
    create table auth.users (id uuid primary key, email text unique, password text);
    create function auth.uid() returns uuid language sql stable as
      $$ select nullif(current_setting('request.jwt.claim.sub', true), '')::uuid $$;
    grant usage on schema auth to anon, authenticated;
    grant execute on function auth.uid() to anon, authenticated;
    grant usage on schema public to anon, authenticated;
    create publication supabase_realtime;
  `);
  await db.exec(readFileSync(join(root, 'supabase/schema.sql'), 'utf8'));
  await db.exec(`
    insert into auth.users values ('${ADMIN_ID}','responsable@test.ma','Admin2026!'),
                                  ('${AGENT_ID}','agent@test.ma','Agent2026!'),
                                  ('${STRANGER_ID}','inconnu@test.ma','Inconnu2026!');
    insert into public.admin_users (user_id, display_name, role) values
      ('${ADMIN_ID}','Responsable','superadmin'), ('${AGENT_ID}','Agent','admin');
  `);
  return db;
}

// Exécute une requête avec le rôle et l'identité demandés (comme PostgREST)
export async function as(db, who, sql, params = [], ip = '10.0.0.1') {
  const role = who === 'anon' ? 'anon' : 'authenticated';
  const sub = who === 'anon' ? '' : who;
  return db.transaction(async (tx) => {
    await tx.query(`select set_config('request.jwt.claim.sub', $1, true), set_config('request.headers', $2, true)`,
      [sub, JSON.stringify({ 'x-forwarded-for': ip })]);
    await tx.exec(`set local role ${role}`);
    const r = await tx.query(sql, params);
    return r.rows;
  });
}

export function localToday() {
  // date du jour à Casablanca (même référence que le serveur)
  const s = new Date().toLocaleString('sv-SE', { timeZone: 'Africa/Casablanca' });
  return s.slice(0, 10);
}
export function addDays(ymd, n) {
  const [y, m, d] = ymd.split('-').map(Number);
  const x = new Date(Date.UTC(y, m - 1, d + n));
  return x.toISOString().slice(0, 10);
}
